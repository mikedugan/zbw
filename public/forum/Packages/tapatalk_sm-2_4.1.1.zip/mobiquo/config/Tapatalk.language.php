<?php

defined('IN_MOBIQUO') or exit;

$tptxt['registration_not_approved'] = 'Sorry, this account has not yet been approved.';
$tptxt['registration_not_activated'] = 'Sorry, this account has not yet been activated.';
